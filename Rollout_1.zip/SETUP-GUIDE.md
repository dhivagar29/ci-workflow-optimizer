# Snyk Branch Cleanup — Setup & Execution Guide

## Overview

This guide walks you through deploying an automated Snyk cleanup system across your repositories. When a feature branch is deleted, stale Snyk project data is automatically removed from your Snyk dashboard.

---

## Architecture at a Glance

```
  ┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
  │  ci-workflow-     │     │   tnelection     │     │     beagle       │
  │  optimizer        │     │                  │     │                  │
  │                   │     │                  │     │                  │
  │  snyk-cleanup.yml │     │  snyk-cleanup.yml│     │  snyk-cleanup.yml│
  │  (caller)         │     │  (caller)        │     │  (caller)        │
  └────────┬──────────┘     └────────┬─────────┘     └────────┬─────────┘
           │                         │                         │
           │         workflow_call   │                         │
           └─────────────┬───────────┘─────────────────────────┘
                         │
                         ▼
           ┌─────────────────────────────┐
           │  dhivagar29/.github         │
           │                             │
           │  snyk-cleanup-reusable.yml  │
           │  (central logic)            │
           │                             │
           │  1. Branch guard check      │
           │  2. Snyk API: list projects │
           │  3. Snyk API: delete each   │
           │  4. Summary log             │
           └─────────────────────────────┘
```

---

## Prerequisites

Before starting, ensure you have:

- **Git Bash (MINGW64)** — Already installed on your IBM machine
- **GitHub CLI (`gh`)** — Install from https://cli.github.com/
- **GitHub PAT** — See Step 1 below
- **Snyk API Token** — From your Snyk account settings
- **Snyk Org ID** — From Snyk Settings → General → Organization ID

---

## Step 1: Create a GitHub Personal Access Token (PAT)

You need a PAT for the `gh` CLI to clone repos, push branches, and create PRs.

1. Go to https://github.com/settings/personal-access-tokens/new
2. Select **Fine-grained token**
3. Set token name: `snyk-cleanup-rollout`
4. Set expiration: 7 days (only needed for rollout)
5. Under **Repository access**, select **Only select repositories**
6. Choose these 3 repos:
   - `dhivagar29/ci-workflow-optimizer`
   - `dhivagar29/tnelection`
   - `dhivagar29/beagle`
7. Under **Permissions → Repository permissions**, set:
   - **Contents**: Read and write
   - **Pull requests**: Read and write
8. Click **Generate token**
9. Copy the token immediately — you won't see it again

> **Alternative**: A Classic PAT with `repo` scope also works but gives broader access than needed.

---

## Step 2: Set Up the Central Reusable Workflow

The reusable workflow contains all the Snyk cleanup logic. It lives in a single central repo (`dhivagar29/.github`) so you only maintain it in one place.

### 2a. Create the `.github` repo (if it doesn't exist)

1. Go to https://github.com/new
2. Set owner to `dhivagar29`
3. Set repository name to `.github`
4. Set visibility to **Public** (required for reusable workflows across repos, unless you have GitHub Enterprise)
5. Check **Add a README file**
6. Click **Create repository**

### 2b. Add the reusable workflow

```bash
# Clone the .github repo
git clone https://github.com/dhivagar29/.github.git
cd .github

# Create the workflows directory
mkdir -p .github/workflows

# Copy the snyk-cleanup-reusable.yml file into .github/workflows/
# (Use the downloaded snyk-cleanup-reusable.yml from our earlier session)
cp /path/to/downloaded/snyk-cleanup-reusable.yml .github/workflows/

# Commit and push
git add .github/workflows/snyk-cleanup-reusable.yml
git commit -m "ci: add reusable Snyk branch cleanup workflow"
git push origin main
```

### 2c. Verify the file is in place

Go to: `https://github.com/dhivagar29/.github/blob/main/.github/workflows/snyk-cleanup-reusable.yml`

The file should be visible.

---

## Step 3: Set Up GitHub Secrets

The workflows need your Snyk credentials. Set them as org-level secrets or per-repo.

### Option A: Per-repo secrets (simpler for 3 repos)

For each of the 3 repos, go to:
`Settings → Secrets and variables → Actions → New repository secret`

Add two secrets:

| Secret Name  | Value                                     |
|-------------|-------------------------------------------|
| `SNYK_TOKEN` | Your Snyk API token                       |
| `SNYK_ORG_ID`| Your Snyk Organization UUID               |

**Where to find these values:**

- **SNYK_TOKEN**: Snyk Dashboard → Account Settings (bottom-left avatar) → General → Auth Token → Click to show → Copy
- **SNYK_ORG_ID**: Snyk Dashboard → Settings → General → Organization ID (UUID format like `4a18d42f-0706-4ad0-b127-24078731fbed`)

### Option B: Org-level secrets (better for 40+ repos)

1. Go to `https://github.com/organizations/dhivagar29/settings/secrets/actions`
2. Click **New organization secret**
3. Add `SNYK_TOKEN` and `SNYK_ORG_ID`
4. Set repository access to **Selected repositories** and pick your repos

---

## Step 4: Run the Rollout Script

The rollout script automatically creates PRs to add the caller workflow to all 3 repos.

### 4a. Prepare your working directory

Create a folder and place these 3 files (downloaded from this conversation) inside it:

```
C:\Dhivagar\Rollout\
├── rollout-snyk-cleanup.sh
├── repos.txt
└── snyk-cleanup.yml          (for reference only; script embeds its own copy)
```

### 4b. Authenticate the GitHub CLI

Open **Git Bash** and run:

```bash
# Option 1: Set as environment variable
export GH_TOKEN=ghp_your_token_from_step_1

# Option 2: Or login interactively
gh auth login
```

Verify authentication:

```bash
gh auth status
```

You should see `Logged in to github.com` with your account.

### 4c. Execute the rollout

```bash
cd /c/Dhivagar/Rollout
chmod +x rollout-snyk-cleanup.sh
./rollout-snyk-cleanup.sh
```

### 4d. Expected output

```
=============================================
  Snyk Cleanup Workflow Rollout
=============================================
  Auth: - Active account: true
  Repos file: /c/Dhivagar/Rollout/repos.txt
=============================================

→ Processing: dhivagar29/ci-workflow-optimizer
  ✓ Branch pushed
https://github.com/dhivagar29/ci-workflow-optimizer/pull/X
  ✓ PR created

→ Processing: dhivagar29/tnelection
  ✓ Branch pushed
https://github.com/dhivagar29/tnelection/pull/X
  ✓ PR created

→ Processing: dhivagar29/beagle
  ✓ Branch pushed
https://github.com/dhivagar29/beagle/pull/X
  ✓ PR created

=============================================
  Rollout Summary
=============================================
  PRs created:  3
  Skipped:      0
  Failed:       0
  Total repos:  3
=============================================
```

### 4e. Merge the PRs

Go to each PR link and merge them:

1. https://github.com/dhivagar29/ci-workflow-optimizer/pulls
2. https://github.com/dhivagar29/tnelection/pulls
3. https://github.com/dhivagar29/beagle/pulls

---

## Step 5: Verify the Automation Works

Pick one repo (e.g., `ci-workflow-optimizer`) and run this end-to-end test:

### 5a. Create a test branch and push it

```bash
cd /path/to/ci-workflow-optimizer
git checkout -b test/snyk-cleanup-verify
git push origin test/snyk-cleanup-verify
```

### 5b. Wait for Snyk CI to scan

Wait for your existing Snyk CI workflow to run on the new branch. Check the Snyk dashboard and confirm a project appears for `test/snyk-cleanup-verify`.

### 5c. Delete the branch

```bash
git push origin --delete test/snyk-cleanup-verify
git checkout main
git branch -D test/snyk-cleanup-verify
```

### 5d. Check the cleanup ran

1. Go to the repo's **Actions** tab on GitHub
2. Look for the workflow run: **"Snyk Cleanup on Branch Delete"**
3. Click into it and verify:
   - Branch guard passed (not a protected branch)
   - Snyk projects were found and deleted
   - Summary shows `Deleted: X, Failed: 0`

### 5e. Confirm on Snyk dashboard

Go to your Snyk dashboard. The project for `test/snyk-cleanup-verify` should be gone.

---

## Troubleshooting

### "Branch already exists" when re-running the rollout

Previous runs left branches behind. Clean them up:

```bash
# Delete the stale branch from a specific repo
gh api -X DELETE repos/dhivagar29/ci-workflow-optimizer/git/refs/heads/chore/add-snyk-cleanup-workflow

# Close any open PR
gh pr close <PR_NUMBER> --repo dhivagar29/ci-workflow-optimizer

# Then re-run
./rollout-snyk-cleanup.sh
```

### Workflow fails with "Snyk API returned HTTP 401"

Your `SNYK_TOKEN` secret is invalid or expired. Generate a new one from Snyk Dashboard → Account Settings → Auth Token, and update the GitHub secret.

### Workflow fails with "Snyk API returned HTTP 404"

Your `SNYK_ORG_ID` is incorrect. Double-check it in Snyk Dashboard → Settings → General → Organization ID.

### Cleanup ran but Snyk projects still show

The Snyk dashboard may take 1-2 minutes to refresh. Hard-refresh the page. Also verify the `target_reference` in the Snyk project matches the exact branch name — if your CI uses a different naming convention, the API filter won't match.

### "LF will be replaced by CRLF" warning

This is a harmless Git warning on Windows. It doesn't affect functionality. To suppress it:

```bash
git config --global core.autocrlf input
```

---

## File Reference

| File | Purpose | Where it goes |
|------|---------|---------------|
| `snyk-cleanup-reusable.yml` | Core cleanup logic (Snyk API calls, retries, branch guard) | `dhivagar29/.github/.github/workflows/` |
| `snyk-cleanup.yml` | Lightweight caller — triggers on branch delete | `.github/workflows/` in each repo (added by rollout script) |
| `rollout-snyk-cleanup.sh` | One-time script to create PRs across all repos | Run locally, then discard |
| `repos.txt` | List of repos to roll out to | Same folder as the rollout script |

---

## Customization

### Adding more repos later

1. Add new repo names to `repos.txt`
2. Re-run `./rollout-snyk-cleanup.sh` — it skips repos that already have the workflow

### Adding more protected branches

Edit `PROTECTED_PATTERNS` in `snyk-cleanup-reusable.yml`:

```bash
PROTECTED_PATTERNS=(
  "^main$"
  "^master$"
  "^develop$"
  "^staging$"        # add custom patterns here
  "^release/.*"
  "^hotfix/.*"
)
```

### Adding Slack notifications on failure

Add this step to the end of `snyk-cleanup-reusable.yml`:

```yaml
- name: Notify on failure
  if: failure()
  run: |
    curl -X POST "${{ secrets.SLACK_WEBHOOK }}" \
      -H 'Content-Type: application/json' \
      -d '{"text": "⚠️ Snyk cleanup failed for branch ${{ inputs.deleted_branch }} in ${{ inputs.repo_name }}"}'
```
