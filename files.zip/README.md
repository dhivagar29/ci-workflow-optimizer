# Snyk Branch Cleanup — Automated Stale Project Removal

## Problem

When feature branches trigger Snyk scans via CI, branch-specific projects are created in Snyk.
After deleting the branch, these Snyk projects persist and clutter the dashboard.

## Solution Architecture

```
Branch deleted on GitHub
         │
         ▼
┌─────────────────────────┐
│  snyk-cleanup.yml       │  ← Lightweight caller in each repo
│  (per-repo caller)      │     Triggers on: delete event
│  Filters: branch only   │
└────────┬────────────────┘
         │ workflow_call
         ▼
┌─────────────────────────┐
│  snyk-cleanup-reusable  │  ← Central reusable workflow
│  .yml (in .github repo) │     Lives in ONE place
│                         │
│  1. Branch guard         │  ← Protected branch check
│  2. Snyk API: list       │  ← GET projects by target_reference
│  3. Snyk API: delete     │  ← DELETE each matching project
│  4. Summary log          │  ← Audit trail in Actions logs
└─────────────────────────┘
```

**Why reusable workflow?** With ~40 repos, you maintain logic in ONE file. Each repo only
needs a 20-line caller workflow. Updates to cleanup logic propagate instantly.

## Files

| File | Where it goes | Purpose |
|------|---------------|---------|
| `snyk-cleanup-reusable.yml` | `your-org/.github/.github/workflows/` | Core cleanup logic (Snyk API calls, retries, branch guard) |
| `snyk-cleanup.yml` | `.github/workflows/` in each of the 40 repos | Lightweight caller — triggers on branch delete |
| `rollout-snyk-cleanup.sh` | Run locally once | Creates PRs to add the caller workflow to all repos |

## Setup — Step by Step

### 1. Set up org-level secrets

In your GitHub org settings → Secrets and variables → Actions:

- `SNYK_TOKEN` — Your Snyk API token (needs `org.project.read` + `org.project.delete` permissions)
- `SNYK_ORG_ID` — Your Snyk organization UUID (find it in Snyk Settings → General → Organization ID)

Make both secrets available to all 40 repositories (or use a repo allowlist).

### 2. Deploy the reusable workflow

```bash
# Clone your org's .github repo (or create one if it doesn't exist)
git clone git@github.com:your-org/.github.git
cd .github

# Copy the reusable workflow
mkdir -p .github/workflows
cp /path/to/snyk-cleanup-reusable.yml .github/workflows/

# Commit and push
git add .github/workflows/snyk-cleanup-reusable.yml
git commit -m "ci: add reusable Snyk branch cleanup workflow"
git push origin main
```

### 3. Update the org name

In **both** YAML files, replace `your-org` with your actual GitHub organization name:

```yaml
# In snyk-cleanup.yml (the caller)
uses: YOUR-ACTUAL-ORG/.github/.github/workflows/snyk-cleanup-reusable.yml@main
```

### 4. Roll out to all repos

Option A — Use the rollout script:

```bash
# Create a repos.txt with one repo per line
cat > repos.txt << EOF
your-org/repo-1
your-org/repo-2
your-org/repo-3
# ... all 40 repos
EOF

chmod +x rollout-snyk-cleanup.sh
./rollout-snyk-cleanup.sh
```

Option B — Manual (per repo):

```bash
# Copy snyk-cleanup.yml to .github/workflows/ in each repo
cp snyk-cleanup.yml /path/to/repo/.github/workflows/
```

### 5. Verify

1. Pick a test repo
2. Create a branch: `git checkout -b test/snyk-cleanup-verify && git push origin test/snyk-cleanup-verify`
3. Wait for the existing Snyk CI to scan the branch
4. Confirm the Snyk project appears on the dashboard
5. Delete the branch: `git push origin --delete test/snyk-cleanup-verify`
6. Check GitHub Actions → "Snyk Cleanup on Branch Delete" ran successfully
7. Confirm the Snyk project is gone from the dashboard

## How It Works — Technical Details

### Branch Protection Guard

The workflow checks the deleted branch name against these patterns before doing anything:

- `main`, `master`, `develop` — exact match
- `release/*`, `hotfix/*` — prefix match

If matched, the workflow exits with a warning log and **zero API calls**.

### Snyk REST API Flow

1. **List projects**: `GET /rest/orgs/{org_id}/projects?target_reference={branch}&version=2024-10-15`
   - The `target_reference` attribute is how Snyk stores the branch name
   - Handles pagination (100 projects per page)

2. **Delete each project**: `DELETE /rest/orgs/{org_id}/projects/{project_id}?version=2024-10-15`
   - Returns 204 on success
   - 404 is treated as "already gone" (idempotent)

### Retry Logic

Both list and delete calls retry up to 3 times with exponential backoff (2s, 4s, 8s) on:
- `429 Too Many Requests` (Snyk rate limiting)
- `5xx` server errors

A 0.5s delay between deletions prevents hitting rate limits.

### Error Handling

- If listing fails after retries → workflow fails with error
- If a single deletion fails → logged, continues with remaining projects, exits non-zero at the end
- 404 on delete → treated as success (project already removed)

## Customization

### Add more protected branches

Edit the `PROTECTED_PATTERNS` array in the reusable workflow:

```bash
PROTECTED_PATTERNS=(
  "^main$"
  "^master$"
  "^develop$"
  "^staging$"              # ← add custom patterns
  "^release/.*"
  "^hotfix/.*"
  "^env/.*"                # ← example: protect environment branches
)
```

### Multiple Snyk orgs

If your 40 repos span multiple Snyk orgs, you can pass `SNYK_ORG_ID` as an input
rather than a secret, and set it per-repo in the caller workflow.

### Notifications on failure

Add a Slack/Teams notification step after the delete step in the reusable workflow:

```yaml
- name: Notify on failure
  if: failure()
  run: |
    curl -X POST "${{ secrets.SLACK_WEBHOOK }}" \
      -H 'Content-Type: application/json' \
      -d '{"text": "⚠️ Snyk cleanup failed for branch ${{ inputs.deleted_branch }} in ${{ inputs.repo_name }}"}'
```
