#!/usr/bin/env bash
# ============================================================================
# rollout-snyk-cleanup.sh
# Distributes the snyk-cleanup.yml caller workflow to multiple repositories.
#
# Prerequisites:
#   - GitHub CLI (gh) authenticated with push access to target repos
#   - The reusable workflow already committed to your-org/.github repo
#
# Usage:
#   ./rollout-snyk-cleanup.sh                   # Uses repos.txt file
#   echo "org/repo1" | ./rollout-snyk-cleanup.sh # Pipe repo list
# ============================================================================

set -euo pipefail

BRANCH_NAME="chore/add-snyk-cleanup-workflow"
WORKFLOW_FILE=".github/workflows/snyk-cleanup.yml"
COMMIT_MSG="ci: add automated Snyk branch cleanup workflow"
PR_TITLE="ci: auto-cleanup stale Snyk projects on branch delete"
PR_BODY="## What

Adds a GitHub Actions workflow that automatically deletes Snyk project data
when a feature branch is deleted. This prevents stale branch scan results
from cluttering the Snyk dashboard.

## How it works

1. Triggers on the \`delete\` event (branch deletion only)
2. Calls a centralized reusable workflow
3. The reusable workflow queries the Snyk REST API for projects matching the deleted branch
4. Deletes all matching projects with retry logic and error handling
5. Protected branches (main, master, develop, release/*, hotfix/*) are never affected

## Testing

1. Create a test branch → push → let Snyk CI scan run
2. Delete the test branch
3. Verify the Snyk dashboard no longer shows projects for that branch
"

# ---- Read repo list ----
if [ -t 0 ] && [ -f "repos.txt" ]; then
  REPOS=$(cat repos.txt)
elif [ ! -t 0 ]; then
  REPOS=$(cat -)
else
  echo "ERROR: No repos provided. Create a repos.txt file (one org/repo per line) or pipe input."
  echo "Example repos.txt:"
  echo "  your-org/repo-1"
  echo "  your-org/repo-2"
  exit 1
fi

# ---- Caller workflow content ----
read -r -d '' WORKFLOW_CONTENT << 'YAML' || true
# Snyk Branch Cleanup — Caller Workflow
# Triggers when a branch is deleted and calls the centralized cleanup workflow.

name: "Snyk Cleanup on Branch Delete"

on:
  delete:

permissions:
  contents: read

jobs:
  snyk-cleanup:
    if: github.event.ref_type == 'branch'
    uses: your-org/.github/.github/workflows/snyk-cleanup-reusable.yml@main
    with:
      deleted_branch: ${{ github.event.ref }}
      repo_name: ${{ github.repository }}
    secrets:
      SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
      SNYK_ORG_ID: ${{ secrets.SNYK_ORG_ID }}
YAML

# ---- Rollout loop ----
SUCCESS=0
FAILED=0
SKIPPED=0

echo "============================================="
echo "  Snyk Cleanup Workflow Rollout"
echo "============================================="
echo ""

while IFS= read -r REPO; do
  # Skip empty lines and comments
  [[ -z "$REPO" || "$REPO" =~ ^# ]] && continue

  echo "→ Processing: $REPO"

  # Check if workflow already exists on default branch
  if gh api "repos/${REPO}/contents/${WORKFLOW_FILE}" --silent 2>/dev/null; then
    echo "  ⚠ Workflow already exists. Skipping."
    SKIPPED=$((SKIPPED + 1))
    continue
  fi

  # Clone, branch, commit, push, PR
  TMPDIR=$(mktemp -d)
  if gh repo clone "$REPO" "$TMPDIR" -- --depth 1 2>/dev/null; then
    cd "$TMPDIR"

    git checkout -b "$BRANCH_NAME" 2>/dev/null

    mkdir -p .github/workflows
    echo "$WORKFLOW_CONTENT" > "$WORKFLOW_FILE"

    git add "$WORKFLOW_FILE"
    git commit -m "$COMMIT_MSG" --quiet

    if git push origin "$BRANCH_NAME" --quiet 2>/dev/null; then
      gh pr create \
        --repo "$REPO" \
        --head "$BRANCH_NAME" \
        --title "$PR_TITLE" \
        --body "$PR_BODY" \
        --label "ci" \
        2>/dev/null && echo "  ✓ PR created" || echo "  ✓ Branch pushed (PR creation may need manual step)"
      SUCCESS=$((SUCCESS + 1))
    else
      echo "  ✗ Failed to push branch"
      FAILED=$((FAILED + 1))
    fi

    cd - > /dev/null
    rm -rf "$TMPDIR"
  else
    echo "  ✗ Failed to clone"
    FAILED=$((FAILED + 1))
    rm -rf "$TMPDIR"
  fi

  echo ""
done <<< "$REPOS"

echo "============================================="
echo "  Rollout Summary"
echo "============================================="
echo "  PRs created: $SUCCESS"
echo "  Skipped:     $SKIPPED"
echo "  Failed:      $FAILED"
echo "============================================="
